import json
import boto3
import os
import sys
import io
import logging

# Pillow will be available via Lambda Layer
from PIL import Image, ImageOps

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')
BUCKET_NAME = os.environ['S3_BUCKET']

def lambda_handler(event, context):
    try:
        processed_count = 0
        
        for record in event['Records']:
            message = json.loads(record['body'])
            
            user_id = message['user_id']
            s3_key = message['s3_key']
            file_id = message['file_id']
            
            logger.info(f"Processing thumbnails for: {s3_key}")
            
            # Check if it's an image or video file
            if is_image_file(s3_key):
                success = create_image_thumbnails(user_id, s3_key, file_id)
                if success:
                    processed_count += 1
                    logger.info(f"Successfully created image thumbnails for {s3_key}")
                else:
                    logger.error(f"Failed to create image thumbnails for {s3_key}")
            elif is_video_file(s3_key):
                success = create_video_thumbnails(user_id, s3_key, file_id)
                if success:
                    processed_count += 1
                    logger.info(f"Successfully created video thumbnails for {s3_key}")
                else:
                    logger.error(f"Failed to create video thumbnails for {s3_key}")
            else:
                logger.info(f"Skipping unsupported file: {s3_key}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'processed': processed_count,
                'total': len(event['Records']),
                'message': 'Thumbnails generated successfully'
            })
        }
        
    except Exception as e:
        logger.error(f"Error processing thumbnails: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def is_image_file(s3_key):
    """Check if file is a supported image format"""
    image_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff']
    return any(s3_key.lower().endswith(ext) for ext in image_extensions)

def is_video_file(s3_key):
    """Check if file is a supported video format"""
    video_extensions = ['.mp4', '.mov', '.avi', '.mkv', '.webm', '.m4v']
    return any(s3_key.lower().endswith(ext) for ext in video_extensions)

def create_image_thumbnails(user_id, s3_key, file_id):
    """Create actual thumbnails using Pillow"""
    try:
        # Download original image
        response = s3.get_object(Bucket=BUCKET_NAME, Key=s3_key)
        image_data = response['Body'].read()
        
        # Open image with Pillow
        with Image.open(io.BytesIO(image_data)) as img:
            # Convert to RGB if necessary
            if img.mode in ('RGBA', 'LA', 'P'):
                img = img.convert('RGB')
            
            # Thumbnail configurations
            thumbnail_configs = {
                'small': {'size': (150, 150), 'path': f"{user_id}/thumbnails/small/{file_id}_s.webp"},
                'medium': {'size': (300, 300), 'path': f"{user_id}/thumbnails/medium/{file_id}_m.webp"},
                'large': {'size': (800, 800), 'path': f"{user_id}/thumbnails/large/{file_id}_l.webp"}
            }
            
            # Generate each thumbnail
            for size_name, config in thumbnail_configs.items():
                # Create thumbnail with crop to fill (like Google Photos)
                thumbnail = img.copy()
                
                # Calculate crop dimensions to maintain aspect ratio and fill square
                img_width, img_height = thumbnail.size
                target_size = config['size'][0]  # Square thumbnails
                
                # Calculate crop box to center the image
                if img_width > img_height:
                    # Landscape: crop width
                    new_width = int(img_height)
                    left = (img_width - new_width) // 2
                    crop_box = (left, 0, left + new_width, img_height)
                else:
                    # Portrait or square: crop height
                    new_height = int(img_width)
                    top = (img_height - new_height) // 2
                    crop_box = (0, top, img_width, top + new_height)
                
                # Crop to square and resize
                thumbnail = thumbnail.crop(crop_box)
                thumbnail = thumbnail.resize(config['size'], Image.Resampling.LANCZOS)
                
                # Save as WebP directly (no white canvas)
                output_buffer = io.BytesIO()
                thumbnail.save(output_buffer, format='WEBP', quality=85, optimize=True)
                output_buffer.seek(0)
                
                # Upload to S3
                s3.put_object(
                    Bucket=BUCKET_NAME,
                    Key=config['path'],
                    Body=output_buffer.getvalue(),
                    ContentType='image/webp',
                    Metadata={
                        'original-file': s3_key,
                        'thumbnail-size': size_name,
                        'dimensions': f"{config['size'][0]}x{config['size'][1]}",
                        'user-id': user_id,
                        'file-id': file_id,
                        'format': 'webp'
                    }
                )
                
                logger.info(f"Created {size_name} thumbnail: {config['path']}")
        
        return True
        
    except Exception as e:
        logger.error(f"Error creating image thumbnails for {s3_key}: {str(e)}")
        return False

def create_video_thumbnails(user_id, s3_key, file_id):
    """Create video thumbnails by extracting frame at 1 second"""
    try:
        import subprocess
        import tempfile
        import os
        
        # Download video file
        response = s3.get_object(Bucket=BUCKET_NAME, Key=s3_key)
        video_data = response['Body'].read()
        
        # Create temporary files
        with tempfile.NamedTemporaryFile(suffix='.mp4', delete=False) as temp_video:
            temp_video.write(video_data)
            temp_video_path = temp_video.name
        
        with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as temp_frame:
            temp_frame_path = temp_frame.name
        
        try:
            # Extract frame at 1 second using ffmpeg
            ffmpeg_cmd = [
                '/opt/bin/ffmpeg',  # Lambda layer path
                '-i', temp_video_path,
                '-ss', '00:00:01.000',  # Seek to 1 second
                '-vframes', '1',  # Extract 1 frame
                '-q:v', '2',  # High quality
                '-y',  # Overwrite output
                temp_frame_path
            ]
            
            result = subprocess.run(ffmpeg_cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode != 0:
                logger.error(f"FFmpeg failed: {result.stderr}")
                # Fallback to placeholder
                return create_video_placeholder(user_id, file_id)
            
            # Process the extracted frame with Pillow
            with Image.open(temp_frame_path) as img:
                # Convert to RGB if necessary
                if img.mode in ('RGBA', 'LA', 'P'):
                    img = img.convert('RGB')
                
                # Thumbnail configurations
                thumbnail_configs = {
                    'small': {'size': (150, 150), 'path': f"{user_id}/thumbnails/small/{file_id}_s.webp"},
                    'medium': {'size': (300, 300), 'path': f"{user_id}/thumbnails/medium/{file_id}_m.webp"},
                    'large': {'size': (800, 800), 'path': f"{user_id}/thumbnails/large/{file_id}_l.webp"}
                }
                
                # Generate each thumbnail
                for size_name, config in thumbnail_configs.items():
                    # Create thumbnail with crop to fill
                    thumbnail = img.copy()
                    
                    # Calculate crop dimensions
                    img_width, img_height = thumbnail.size
                    
                    if img_width > img_height:
                        # Landscape: crop width
                        new_width = int(img_height)
                        left = (img_width - new_width) // 2
                        crop_box = (left, 0, left + new_width, img_height)
                    else:
                        # Portrait or square: crop height
                        new_height = int(img_width)
                        top = (img_height - new_height) // 2
                        crop_box = (0, top, img_width, top + new_height)
                    
                    # Crop to square and resize
                    thumbnail = thumbnail.crop(crop_box)
                    thumbnail = thumbnail.resize(config['size'], Image.Resampling.LANCZOS)
                    
                    # Save as WebP
                    output_buffer = io.BytesIO()
                    thumbnail.save(output_buffer, format='WEBP', quality=85, optimize=True)
                    output_buffer.seek(0)
                    
                    # Upload to S3
                    s3.put_object(
                        Bucket=BUCKET_NAME,
                        Key=config['path'],
                        Body=output_buffer.getvalue(),
                        ContentType='image/webp',
                        Metadata={
                            'original-file': s3_key,
                            'thumbnail-size': size_name,
                            'dimensions': f"{config['size'][0]}x{config['size'][1]}",
                            'user-id': user_id,
                            'file-id': file_id,
                            'format': 'webp',
                            'type': 'video-frame'
                        }
                    )
                    
                    logger.info(f"Created {size_name} video thumbnail: {config['path']}")
            
            return True
            
        finally:
            # Clean up temporary files
            try:
                os.unlink(temp_video_path)
                os.unlink(temp_frame_path)
            except:
                pass
        
    except Exception as e:
        logger.error(f"Error creating video thumbnails for {s3_key}: {str(e)}")
        # Fallback to placeholder
        return create_video_placeholder(user_id, file_id)

def create_video_placeholder(user_id, file_id):
    """Create placeholder thumbnails for videos when ffmpeg fails"""
    try:
        thumbnail_configs = {
            'small': {'size': (150, 150), 'path': f"{user_id}/thumbnails/small/{file_id}_s.webp"},
            'medium': {'size': (300, 300), 'path': f"{user_id}/thumbnails/medium/{file_id}_m.webp"},
            'large': {'size': (800, 800), 'path': f"{user_id}/thumbnails/large/{file_id}_l.webp"}
        }
        
        for size_name, config in thumbnail_configs.items():
            # Create a dark placeholder with play icon
            img = Image.new('RGB', config['size'], (32, 32, 32))
            
            # Save as WebP
            output_buffer = io.BytesIO()
            img.save(output_buffer, format='WEBP', quality=85, optimize=True)
            output_buffer.seek(0)
            
            # Upload to S3
            s3.put_object(
                Bucket=BUCKET_NAME,
                Key=config['path'],
                Body=output_buffer.getvalue(),
                ContentType='image/webp',
                Metadata={
                    'original-file': s3_key,
                    'thumbnail-size': size_name,
                    'dimensions': f"{config['size'][0]}x{config['size'][1]}",
                    'user-id': user_id,
                    'file-id': file_id,
                    'format': 'webp',
                    'type': 'video-placeholder'
                }
            )
            
            logger.info(f"Created {size_name} video placeholder: {config['path']}")
        
        return True
        
    except Exception as e:
        logger.error(f"Error creating video placeholder for {file_id}: {str(e)}")
        return False
